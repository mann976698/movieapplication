import { Component, OnInit } from '@angular/core';
import { AppsettingServiceService } from './appsetting-service.service';
import { Moviedetails } from '../moviedetails.modal';

@Component({
  selector: 'app-movielist',
  templateUrl: './movielist.component.html',
  styleUrls: ['./movielist.component.css']
})
export class MovielistComponent implements OnInit {
 data :  Moviedetails[];
  
  
  constructor(private appSettingsService : AppsettingServiceService) {
    console.log(this.data);
   }

  ngOnInit() {
    this.appSettingsService.getJSON().subscribe(data => {
      data.forEach(element => {
        return data
      });
      
    })
}
}
