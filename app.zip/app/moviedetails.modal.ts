export class Moviedetails {
    id:number
    name:string
    rating:number
    releasedate:Date
}
