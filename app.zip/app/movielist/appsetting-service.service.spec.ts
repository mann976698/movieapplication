import { TestBed, inject } from '@angular/core/testing';

import { AppsettingServiceService } from './appsetting-service.service';

describe('AppsettingServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppsettingServiceService]
    });
  });

  it('should be created', inject([AppsettingServiceService], (service: AppsettingServiceService) => {
    expect(service).toBeTruthy();
  }));
});
